print("Welcome to Number Teller!")

try:
    mark = int(input("Please input marks: "))
    
    if mark < 0 or mark > 100:
        print("Please enter a number between 0 and 100.")
    elif mark < 30:
        print("Grade: F")
    elif mark < 40:
        print("Grade: E")
    elif mark < 55:
        print("Grade: D")
    elif mark < 65:
        print("Grade: C")
    elif mark < 75:
        print("Grade: B")
    elif mark < 85:
        print("Grade: A")
    else:
        print("Grade: A+")
except ValueError:
    print("Invalid input. Please enter a number.")