# Step 1: Allow the user to enter 5 numbers and store them in a list
numbers = []

for i in range(5):
    num = float(input(f"Enter number {i + 1}: "))
    numbers.append(num)

# Step 2a: Display the list of numbers
print("\nYou entered:", numbers)

# Step 2b: Display the maximum, minimum, and average
maximum = max(numbers)
minimum = min(numbers)
average = sum(numbers) / len(numbers)

print("Maximum:", maximum)
print("Minimum:", minimum)
print("Average:", average)

# Step 2c: Display the list in sorted order
sorted_numbers = sorted(numbers)
print("Sorted list:", sorted_numbers)
